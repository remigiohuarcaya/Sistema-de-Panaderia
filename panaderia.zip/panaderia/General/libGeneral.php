<?php

function cabecera(){
    echo "<div class='container'>";
   
    echo "<img src='../images/banner-panaderia.jpg' >";
    
    echo "</div>";
}
Function pie(){
    
}
?>
